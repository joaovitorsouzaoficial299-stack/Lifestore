# Site de assistência técnica

Site estático em HTML, CSS e JavaScript puros. Não precisa instalar nada.

```
assistencia/
├── index.html
├── css/style.css      (visual e celular 3D)
├── js/config.js       (TODOS os dados da loja)
├── js/main.js         (animação de desmontar e interações)
└── assets/            (favicon e, se quiser, frames/)
```

## 1. Personalizar
Abra `js/config.js` e troque: nome, slogan, WhatsApp (só dígitos, com 55 + DDD), Instagram,
endereço, horários, serviços e preços, depoimentos e perguntas frequentes.
Para trocar as cores, edite as variáveis no começo de `css/style.css` (`--blue`, `--navy`, `--cyan`).

## 2. O celular que desmonta com a rolagem
Fica na seção "Por dentro". Ao rolar para baixo as peças se separam (vidro, display, placa,
bateria e carcaça). Ao rolar para cima elas se encaixam de novo. Os textos de cada peça ficam
em `partes` no `config.js`, e o botão "Orçar" de cada peça já preenche o formulário.

### Usar frames reais (opcional)
Se você tiver uma sequência de imagens do aparelho desmontando (exportada de um vídeo):
1. Coloque os arquivos em `assets/frames/` com os nomes `001.jpg`, `002.jpg`, `003.jpg`...
2. No `config.js`, troque `stage: { frames: null }` por
   `stage: { frames: { pasta: "assets/frames/", total: 120, ext: "jpg" } }` (use o total real).
O site passa a desenhar o frame certo conforme a rolagem, para frente e para trás.

## 3. Testar no computador
Dê dois cliques no `index.html`.

## 4. Subir no GitHub e publicar de graça
1. Crie um repositório novo em github.com (ex.: `minha-assistencia`), público.
2. Clique em **Add file > Upload files** e arraste TODO o conteúdo da pasta `assistencia/`
   (o `index.html` precisa ficar na raiz). Clique em **Commit changes**.
3. Vá em **Settings > Pages**, escolha o branch `main` e a pasta `/ (root)`, e clique em **Save**.
4. Em 1 a 2 minutos o site abre em `https://SEU-USUARIO.github.io/minha-assistencia/`.

## Observações
- Preços e textos da demonstração são fictícios. Troque pelos reais.
- As fontes vêm do Google Fonts; sem internet o site usa fontes do sistema.
